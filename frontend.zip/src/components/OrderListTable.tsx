import { useState, useEffect } from "react";
import axios from "axios";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";

interface OrderData {
  id: string;
  orderDate: string;
  orderState: string;
  retailPrice: number;
}

interface InvoiceData {
  id: string;
  taxRateInPercentage: number;
  nettoPrice: number;
  bruttoPrice: number;
}

interface OrderListTableProps {
  customerId: string | null;
  showCustomerList: () => void;
  setInvoiceData: React.Dispatch<React.SetStateAction<InvoiceData | null>>;
  setShowInvoice: React.Dispatch<React.SetStateAction<boolean>>;
}

const columns: readonly { id: keyof OrderData; label: string }[] = [
  { id: "orderDate", label: "Order Date" },
  { id: "orderState", label: "Order Status" },
  { id: "retailPrice", label: "Order Retail Price (PLN)" },
];

const rowHoverStyle = {
  cursor: "pointer",
  "&:hover": {
    backgroundColor: "rgba(0, 0, 0, 0.04)",
  },
};

export default function OrderListTable({
  customerId,
  showCustomerList,
  setInvoiceData, // Add a prop to set the invoice data in the parent component
  setShowInvoice, // Add a prop to show the InvoicePage in the parent component
}: OrderListTableProps) {
  const handleGoBack = () => {
    showCustomerList();
  };

  const [orders, setOrders] = useState<OrderData[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<OrderData | null>(null);

  const handleGetInvoice = async (orderId: string) => {
    try {
      const response = await axios.get(
        `http://localhost:8080/invoice/${orderId}`
      );
      setInvoiceData(response.data);
      setShowInvoice(true);
    } catch (error) {
      console.error("There was an error fetching the invoice!", error);
    }
  };

  useEffect(() => {
    // Only fetch orders if customerId is not null
    if (customerId) {
      const fetchOrders = async () => {
        try {
          const response = await axios.get(
            `http://localhost:8080/order/customerOrders/${customerId}`
          );
          setOrders(response.data);
        } catch (error) {
          console.error("There was an error fetching the orders!", error);
        }
      };

      fetchOrders();
    } else {
      // If customerId is null, reset the orders
      setOrders([]);
    }
  }, [customerId]);

  const handleRowClick = (order: OrderData) => {
    setSelectedOrder(order);
  };

  return (
    <div className="flex flex-col h-[550px] min-h-[680px]">
      <button
        className="w-[150px] h-[30px] mt-4 mb-4 bg-gray-400 rounded-lg text-center font-bold"
        onClick={handleGoBack}
      >
        Go Back
      </button>
      <Paper
        sx={{
          margin: "auto",
          width: "80%",
          overflow: "hidden",
          border: "1px solid grey",
          marginBottom: "auto",
        }}
      >
        {/* title for  table */}
        <div className="flex justify-center mb-4 bg-gray-300 rounded-md">
          List of our customers
        </div>
        <TableContainer sx={{ maxHeight: 440 }}>
          <Table stickyHeader aria-label="sticky table">
            <TableHead>
              <TableRow>
                {columns.map((column) => (
                  <TableCell key={column.id}>{column.label}</TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {orders.map((order) => (
                <TableRow
                  hover
                  role="checkbox"
                  tabIndex={-1}
                  key={order.id}
                  onClick={() => handleRowClick(order)}
                  sx={rowHoverStyle}
                >
                  {columns.map((column) => (
                    <TableCell key={column.id}>{order[column.id]}</TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>
      {selectedOrder && (
        <div className="flex justify-around items-center h-14 rounded-md bg-[#DBE4EF] mt-4">
          <span>Selected order: </span>
          <div>
            Order from: {selectedOrder.orderDate} | ID: {selectedOrder.id}
            <button
              className="w-[250px] h-[30px] ml-10 bg-blue-500 rounded-lg text-center font-bold text-white"
              onClick={() => handleGetInvoice(selectedOrder.id)}
            >
              Get an invoice
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
