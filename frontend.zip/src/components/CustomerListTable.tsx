import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import axios from "axios";
import { useState, useEffect } from "react";

interface Column {
  id: "FirstName" | "Lastname" | "Email";
  label: string;
}

const columns: readonly Column[] = [
  { id: "FirstName", label: "FirstName" },
  { id: "Lastname", label: "Lastname" },
  { id: "Email", label: "Email" },
];

interface CustomerData {
  id: string;
  address: string | null;
  email: string;
  firstName: string;
  lastName: string;
}

interface CustomerListTableProps {
  setSelectedCustomerId: React.Dispatch<React.SetStateAction<string | null>>;
  setShowOrders: React.Dispatch<React.SetStateAction<boolean>>;
}

const rowHoverStyle = {
  cursor: "pointer",
  "&:hover": {
    backgroundColor: "rgba(0, 0, 0, 0.04)", // Or any other color
  },
};

export default function CustomerListTable({
  setSelectedCustomerId,
  setShowOrders,
}: CustomerListTableProps) {
  const [customers, setCustomers] = useState<CustomerData[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerData | null>(
    null
  );

  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const response = await axios.get(
          "http://localhost:8080/customer/getAllCustomers"
        );
        setCustomers(response.data);
      } catch (error) {
        console.error("There was an error fetching the customers!", error);
      }
    };

    fetchCustomers();
  }, []);

  const handleRowClick = (customer: CustomerData) => {
    setSelectedCustomer(customer);
    setSelectedCustomerId(customer.id); // Set the selected customer ID
  };
  return (
    <div className="flex flex-col h-[550px] min-h-[680px]">
      <div className="flex justify-center mb-10 bg-gray-300 rounded-md">
        Customer list
      </div>
      <Paper
        sx={{
          marginLeft: "auto",
          marginRight: "auto",
          width: "80%",
          overflow: "hidden",
          border: "1px solid grey",
          marginBottom: "auto",
        }}
      >
        <TableContainer sx={{ maxHeight: 440 }}>
          <Table stickyHeader aria-label="sticky table">
            <TableHead>
              <TableRow>
                {columns.map((column) => (
                  <TableCell key={column.id}>{column.label}</TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {customers.map((customer) => (
                <TableRow
                  hover
                  role="checkbox"
                  tabIndex={-1}
                  key={customer.id}
                  onClick={() => handleRowClick(customer)}
                  sx={rowHoverStyle}
                >
                  <TableCell>{customer.firstName}</TableCell>
                  <TableCell>{customer.lastName}</TableCell>
                  <TableCell>{customer.email}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>
      <div className="flex justify-around items-center h-14 rounded-md mt-16 bg-[#DBE4EF]">
        <button
          className="w-[250px] h-[30px] ml-10 bg-white rounded-lg text-center font-bold"
          onClick={() => setShowOrders(true)} // Call setShowOrders when the button is clicked
        >
          Show Customer's Orders
        </button>
        <span>Selected customer: </span>
        {selectedCustomer && (
          <div>
            FullName: {selectedCustomer.firstName} {selectedCustomer.lastName}
            <span className="ml-10">Email: {selectedCustomer.email}</span>
          </div>
        )}
      </div>
    </div>
  );
}
